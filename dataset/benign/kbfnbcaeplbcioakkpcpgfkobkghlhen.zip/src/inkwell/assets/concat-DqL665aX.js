import{m as o,p as t}from"./mergeAll-CSDR5lBs.js";import{J as n}from"./index-uVYElzgq.js";function e(){return o(1)}function s(){for(var a=[],r=0;r<arguments.length;r++)a[r]=arguments[r];return e()(n(a,t(a)))}export{e as a,s as c};
//# sourceMappingURL=concat-DqL665aX.js.map
