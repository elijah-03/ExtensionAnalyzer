"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0000c526-edcb-576b-9a9c-a35c8f679978")}catch(e){}}();
(self.webpackChunk_loomhq_chrome_extension=self.webpackChunk_loomhq_chrome_extension||[]).push([[31238],{45414:(e,o,t)=>{Object.defineProperty(o,"__esModule",{value:!0}),o.default=void 0;var a=l(t(92860)),c=l(t(6895)),n=l(t(49608));function l(e){return e&&e.__esModule?e:{default:e}}const u=e=>a.default.createElement(c.default,Object.assign({name:"LockLockedIcon",LEGACY_fallbackIcon:n.default},e));u.displayName="LockLockedIconMigration",o.default=u}}]);
//# sourceMappingURL=@atlaskit-internal_glyphForbidden.js.map
//# debugId=0000c526-edcb-576b-9a9c-a35c8f679978
