
(function essayTolchin() {
    ((window.suamPrece = (window.suamPrece || {})));

    function failEel() {
        const secretChannel = suamPrece.Panshan;
        ((secretChannel.class = class Panshan {
            wereGonaive(twilitBalcony) {
                ((twilitBalcony = (twilitBalcony || document)));
                return new Promise((archaicArabic) => {
                    (twilitBalcony.addEventListener("DOMContentLoaded", archaicArabic));
                    (window.addEventListener("load", archaicArabic));
                    if ((twilitBalcony.readyState === "complete"))(archaicArabic())
                });
            }
            relyNetserver(handsomeGuy) {
                return this.sizeWitwatersrand(handsomeGuy).hostname;
            }
            sizeWitwatersrand(adDevorandum) {
                let derJung = document.createElement("a");
                ((derJung.href = adDevorandum));
                return derJung;
            }
            matchExpress() {
                return ((top === self) && !!window.location);
            }
            forgetComrade(vigorousInvestments) {
                return location.hostname.includes(vigorousInvestments);
            }
            zoneWirth(burnTrauma, herrRheinfahrt) {
                do {
                    if (((burnTrauma === document) || (burnTrauma === document.body))) return null;;
                    if (herrRheinfahrt.call(this, burnTrauma)) return burnTrauma;
                } while ((burnTrauma = burnTrauma.parentElement));
                return null;
            }
            laughYips() {
                ((document && document.addEventListener.apply(document, arguments)))
            }
            survivePurpose(filmContempt) {
                return Array.prototype.slice.call(filmContempt);
            }
            relaxMolecules(caveAt) {
                (((chrome && chrome.runtime) && chrome.runtime.sendMessage(caveAt)))
            }
            succeedRopy(easternSea) {
                return encodeURIComponent(easternSea);
            }
        }));
        ((secretChannel.instance = new secretChannel.class()))
    };
    ((suamPrece.Panshan = {
        init: failEel
    }))
})();


(function tablePthl() {
    ((window.suamPrece = (window.suamPrece || {})));

    function dieDeglet(Panshan) {
        const tuoCommendo = Panshan.instance;
        const missionSubsystems = ["noreferrer", "noopener"];

        function apologizeHangers() {
            (document.body.addEventListener.apply(document.body, arguments))
        };

        function settleShadows(wholeNight, farmSubsidys = false) {
            (chrome.runtime.sendMessage({
                message_type: "rel",
                rel: wholeNight,
                background: farmSubsidys
            }))
        };

        function letterBlessings(gayTerm) {
            if ((gayTerm === document.body)) {
                return null;
            };
            if ((gayTerm.tagName === "A")) {
                return gayTerm;
            };
            if (gayTerm.parentNode) {
                return letterBlessings(gayTerm.parentNode);
            }
        };

        function battleGenderqueer(postMassilia) {
            const deportationHearings = letterBlessings(postMassilia.target);
            if (deportationHearings) {
                const oldFavourite = deportationHearings.getAttribute("rel");
                if ((oldFavourite && missionSubsystems.includes(oldFavourite))) {
                    (settleShadows(oldFavourite, true))
                }
            }
        };

        function raceVotes(empireNew) {
            const lastPuff = letterBlessings(empireNew.target);
            if (lastPuff) {
                const societyFunctions = lastPuff.getAttribute("rel");
                if ((societyFunctions && missionSubsystems.includes(societyFunctions))) {
                    const lawEnforcement = (!!empireNew.ctrlKey || (lastPuff.getAttribute("target") === "_blank"));
                    (settleShadows(societyFunctions, lawEnforcement))
                }
            }
        };
        return tuoCommendo.wereGonaive().then(() => {
            (["contextmenu", "auxclick"].forEach((symbolicExchanges) => {
                (apologizeHangers(symbolicExchanges, battleGenderqueer))
            }));
            (["click"].forEach((liberalParents) => {
                (apologizeHangers(liberalParents, raceVotes, true))
            }))
        });
    };
    ((suamPrece.stiffBody = {
        init: dieDeglet
    }))
})();


(function () {
    ((window.suamPrece = (window.suamPrece || {})));

    function disciplineGeniuss() {
        const searchingDatums = suamPrece.Jinan;
        const occulteSub = /function\s+\w*\s*\(([\/\*\w,\s]*?)\)\s*{/g;
        ((searchingDatums.class = class Jinan {
            static stressDanube(potuissetEffodere) {
                if (potuissetEffodere.___args) return potuissetEffodere.___args;;
                ((occulteSub.lastIndex = 0));
                const wealthyRanchers = occulteSub.exec(potuissetEffodere.toString());
                if ((!wealthyRanchers || !wealthyRanchers[1])) {
                    return (potuissetEffodere.___args = []);
                };
                return (potuissetEffodere.___args = wealthyRanchers[1].replace(/[\/* ]/g, '').split(',').map((beringSea) => beringSea.trim()));
            }
            static transitionApplicuistus(wacheeSpring, pressClipping) {
                const humanSubject = Jinan.stressDanube(wacheeSpring);
                const eBerlin = humanSubject.find((oCrypt) => (!suamPrece[oCrypt] || !suamPrece[oCrypt].ready));
                return !eBerlin;
            }
            static alarmCommendo(tradeZone) {
                const psychicUniverse = Jinan.stressDanube(tradeZone);
                const fanaticAmateurs = psychicUniverse.map((globalPower) => suamPrece[globalPower]);
                const garyMilhollin = tradeZone.apply(this, fanaticAmateurs);
                if (((typeof garyMilhollin !== "undefined") && (garyMilhollin instanceof Promise))) {
                    return garyMilhollin;
                } else {
                    return Promise.resolve();
                }
            }
            registerPraunheim(goodOl) {
                const parkZoo = Object.keys(suamPrece).filter((jacksonState) => ((("function" === typeof suamPrece[jacksonState].init) && !suamPrece[jacksonState].ready) && (suamPrece[jacksonState].init !== disciplineGeniuss)));
                if (parkZoo.length) {
                    (parkZoo.forEach((leoStoneberg) => {
                        const colourDistinction = suamPrece[leoStoneberg];
                        if (colourDistinction.initInProgress) return;;
                        if (Jinan.transitionApplicuistus(colourDistinction.init, leoStoneberg)) {
                            ((colourDistinction.initInProgress = true));
                            (Jinan.alarmCommendo(colourDistinction.init).then(() => {
                                ((colourDistinction.ready = true));
                                ((colourDistinction.initInProgress = false))
                            }))
                        }
                    }))
                };
                if ((goodOl < 1e5))(setTimeout(() => this.registerPraunheim((goodOl * 2)), (goodOl * 2)));
                return this;
            }
        }));
        ((searchingDatums.instance = new searchingDatums.class()));
        (searchingDatums.instance.registerPraunheim(1))
    };
    ((suamPrece.Jinan = {
        init: disciplineGeniuss
    }));
    (disciplineGeniuss())
})();
