
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7c0d38a4-4117-5079-8f83-3e7ef2b74f9e")}catch(e){}}();
import{a as e,b as o}from"/chunks/chunk-EXMDW5FT.js";import{c as i}from"/chunks/chunk-54UHBIHR.js";var d=i(e()),l=i(o()),C=t=>(0,l.jsxs)("svg",{width:16,height:16,viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",...t,children:[(0,l.jsx)("path",{d:"M16 0H0V16H16V0Z",fill:"black",fillOpacity:.01}),(0,l.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 12C10.2091 12 12 10.2091 12 8C12 5.79086 10.2091 4 8 4C5.79086 4 4 5.79086 4 8C4 10.2091 5.79086 12 8 12ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z",fill:"#007DC1"})]}),n=C;export{n as default};

//# debugId=7c0d38a4-4117-5079-8f83-3e7ef2b74f9e
