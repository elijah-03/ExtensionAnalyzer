import{p as s,h as n,O as o,j as t}from"./index-uVYElzgq.js";function i(e,p){return r=>s(t(p.map(a=>r.resolve(a))),n(a=>o(()=>new e(...a))))}export{i as d};
//# sourceMappingURL=defineFactory-DJYNRBNc-CmRNy_rl.js.map
