
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1ca024de-29f1-5cea-8e8a-9dd5cdf4b655")}catch(e){}}();
var e="https://op8.agilebits.com/extension/report-issue";var o={"/":"INLINE_MENU_ITEMS","/frozen-accounts":"INLINE_MENU_FROZEN_ACCOUNTS","/overflow/*":void 0,"/overflow/options":"INLINE_MENU_OVERFLOW_MENU","/overflow/password-generator":"INLINE_MENU_PASSWORD_GENERATOR"};export{e as a,o as b};

//# debugId=1ca024de-29f1-5cea-8e8a-9dd5cdf4b655
