import{U as o}from"./start-BFd-djfI.js";function s(e){switch(e){case"extension-chrome":case"extension-firefox":case"extension-safari":case"preview-web":return"showAllDocuments";case"windows":case"preview-windows":return"showActiveDocumentOnly";default:throw new o(e)}}export{s as g};
//# sourceMappingURL=getDecorationStrategy-ByPikn4k.js.map
