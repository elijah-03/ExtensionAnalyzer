import{at as p,au as i}from"./start-BFd-djfI.js";function u(){return p(function(n,r){var a,e=!1;n.subscribe(i(r,function(t){var o=a;a=t,e&&r.next([o,t]),e=!0}))})}export{u as p};
//# sourceMappingURL=pairwise-CN9hSkDF.js.map
