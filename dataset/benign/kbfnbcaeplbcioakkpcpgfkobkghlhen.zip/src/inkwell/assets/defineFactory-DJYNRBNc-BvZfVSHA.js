import{p as s,h as n,I as o,j as t}from"./start-BFd-djfI.js";function i(e,p){return r=>s(t(p.map(a=>r.resolve(a))),n(a=>o(()=>new e(...a))))}export{i as d};
//# sourceMappingURL=defineFactory-DJYNRBNc-BvZfVSHA.js.map
