import{d as o}from"./PluginModule-CRib3PLZ-B43Hjk20.js";import{c as n}from"./start-BFd-djfI.js";const c=n(Symbol("CAPIConnection")),i=o({background:()=>import("./index-DwCYgNrj.js")});export{c as CAPIConnectionToken,i as activate};
//# sourceMappingURL=index-B9uHfCTo.js.map
