
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="45eac7fa-f181-5cca-93b7-cfb58909dbb3")}catch(e){}}();
import"/chunks/chunk-54UHBIHR.js";var P="/assets/png/icon_bankaccount_color_64@2x-EWCHBQ2Y.png";export{P as default};

//# debugId=45eac7fa-f181-5cca-93b7-cfb58909dbb3
