var fvdSingleDownloader = {
	noYoutube: true,
	noLink:    true,
	noImage:   true,
	noFile:    true,
	noGame:    false,
	noWelcome: false,
};