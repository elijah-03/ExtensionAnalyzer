import{c as o}from"./concat-DqL665aX.js";import{p as n}from"./mergeAll-CSDR5lBs.js";import{aK as m}from"./index-uVYElzgq.js";function f(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];var a=n(r);return m(function(e,s){(a?o(r,e,a):o(r,e)).subscribe(s)})}export{f as s};
//# sourceMappingURL=startWith-DFLDsqXv.js.map
