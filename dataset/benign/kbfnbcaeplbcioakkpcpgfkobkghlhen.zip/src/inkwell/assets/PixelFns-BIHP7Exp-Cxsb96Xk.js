function e(t){return t}function i(t){return t*window.devicePixelRatio}export{e as c,i as t};
//# sourceMappingURL=PixelFns-BIHP7Exp-Cxsb96Xk.js.map
