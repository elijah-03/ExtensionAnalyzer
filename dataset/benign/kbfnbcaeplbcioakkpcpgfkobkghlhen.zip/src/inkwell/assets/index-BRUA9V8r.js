import{d as o}from"./PluginModule-CRib3PLZ-B43Hjk20.js";import{c as n}from"./start-BFd-djfI.js";const r=n(Symbol("SDUIManger")),a=n(Symbol("InlineCardContent")),i=o({background:()=>import("./index-Db_x7cK_.js"),foreground:()=>import("./index-rqlhpUDb.js")});export{a as InlineCardContentToken,r as SDUIManagerToken,i as activate};
//# sourceMappingURL=index-BRUA9V8r.js.map
