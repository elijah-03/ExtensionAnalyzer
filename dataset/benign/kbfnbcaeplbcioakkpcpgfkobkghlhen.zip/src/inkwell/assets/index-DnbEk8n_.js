import{d as o}from"./PluginModule-CRib3PLZ-B43Hjk20.js";import{c as t}from"./start-BFd-djfI.js";const n=t(Symbol("TextDecorationController")),c=o({background:()=>import("./index-O7PIDOzs.js"),foreground:()=>import("./index-BUGw0CJ-.js")});export{n as TextDecorationControllerToken,c as activate};
//# sourceMappingURL=index-DnbEk8n_.js.map
