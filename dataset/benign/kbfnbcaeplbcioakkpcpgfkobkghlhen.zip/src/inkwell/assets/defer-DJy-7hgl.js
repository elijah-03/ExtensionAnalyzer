import{Z as n,aD as o}from"./start-BFd-djfI.js";function a(r){return new n(function(e){o(r()).subscribe(e)})}export{a as d};
//# sourceMappingURL=defer-DJy-7hgl.js.map
