function r(e){return{x:e.x,y:e.y}}function u(e,t){return Math.abs(e.x-t.x)<Number.EPSILON&&Math.abs(e.y-t.y)<Number.EPSILON}function a(e){return t=>r({x:t.x+e.x,y:t.y+e.y})}export{r as c,u as e,a as t};
//# sourceMappingURL=PointFns-Bd1JBOhL--ZyEh-AF.js.map
