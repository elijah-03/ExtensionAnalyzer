function t(n){const r=Array.isArray(n)?n:Array.from(n);return r.length>0?r:null}function a(n){return r=>r.map(n)}function o(n){return r=>r.length>0?n.nonEmpty(r):n.empty()}export{o as a,t as f,a as m};
//# sourceMappingURL=NonEmptyArrayFns-oGa02u3x-CLyX5YlY.js.map
