import{ar as r,r as e}from"./index-uVYElzgq.js";import{r as m}from"./race-DbiJq4jp.js";import{t as u}from"./timer-B6bjwuU9.js";import{t as i}from"./tap-BL_zgIju.js";async function s(t,a){return await r(m([t,u(a.timeoutMs).pipe(i(a.onTimeout),e(()=>a.defaultValue))]),{defaultValue:a.defaultValue})}export{s as t};
//# sourceMappingURL=timeoutWith-B7tsbJ8--DgEQKW6j.js.map
