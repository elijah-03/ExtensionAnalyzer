import{E as o}from"./mergeAll-D275NTmK.js";import{at as f,au as i}from"./start-BFd-djfI.js";function u(t){return t<=0?function(){return o}:f(function(a,e){var r=0;a.subscribe(i(e,function(n){++r<=t&&(e.next(n),t<=r&&e.complete())}))})}export{u as t};
//# sourceMappingURL=take-gJdc_Sb0.js.map
