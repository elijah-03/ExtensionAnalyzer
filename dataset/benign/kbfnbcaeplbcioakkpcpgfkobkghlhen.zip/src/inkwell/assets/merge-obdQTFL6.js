import{p as o,b as s,E as t,m as u}from"./mergeAll-D275NTmK.js";import{aD as g,D as p}from"./start-BFd-djfI.js";function f(){for(var r=[],e=0;e<arguments.length;e++)r[e]=arguments[e];var n=o(r),m=s(r,1/0),a=r;return a.length?a.length===1?g(a[0]):u(m)(p(a,n)):t}export{f as m};
//# sourceMappingURL=merge-obdQTFL6.js.map
