import{d as o}from"./PluginModule-CRib3PLZ-B43Hjk20.js";import{c as e}from"./start-BFd-djfI.js";const r=e(Symbol("SuggestionStoreManager")),i=e(Symbol("SuggestionService")),a=o({background:()=>import("./index-Bz_nL0tC.js")});export{i as SuggestionServiceToken,r as SuggestionStoreManagerToken,a as activate};
//# sourceMappingURL=index-BOWMRPqo.js.map
