import{m as o,p as t}from"./mergeAll-D275NTmK.js";import{D as n}from"./start-BFd-djfI.js";function e(){return o(1)}function s(){for(var a=[],r=0;r<arguments.length;r++)a[r]=arguments[r];return e()(n(a,t(a)))}export{e as a,s as c};
//# sourceMappingURL=concat-Bl9EyBSW.js.map
