function r(n){return{x:n.x,y:n.y}}function t(n){return r(n)}export{r as c,t as w};
//# sourceMappingURL=ScreenPointFns-7sGy0XGN-DYTqdHzE.js.map
