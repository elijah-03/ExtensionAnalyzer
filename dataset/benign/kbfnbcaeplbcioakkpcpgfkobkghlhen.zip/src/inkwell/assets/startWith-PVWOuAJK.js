import{c as o}from"./concat-Bl9EyBSW.js";import{p as n}from"./mergeAll-D275NTmK.js";import{at as m}from"./start-BFd-djfI.js";function f(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];var a=n(r);return m(function(e,s){(a?o(r,e,a):o(r,e)).subscribe(s)})}export{f as s};
//# sourceMappingURL=startWith-PVWOuAJK.js.map
