["teams.microsoft.com"].includes(window.location.hostname)&&window.trustedTypes&&(window.refTrustedTypes=window.trustedTypes,delete window.trustedTypes);
