const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./index-BUQoVyfC.js","./index-uVYElzgq.js","./index-lcMbSU65.css","./index-BbX8QEjx.js","./PluginModule-CRib3PLZ-LTQDm_KX.js"])))=>i.map(i=>d[i]);
import{c as e,_ as o}from"./index-uVYElzgq.js";import{d as i}from"./PluginModule-CRib3PLZ-LTQDm_KX.js";const a=e(Symbol("MainView")),r=e(Symbol("MainViewContainer")),m=i({foreground:()=>o(()=>import("./index-BUQoVyfC.js"),__vite__mapDeps([0,1,2,3,4]),import.meta.url)});export{r as MainViewContainerToken,a as MainViewToken,m as activate};
//# sourceMappingURL=index-OKQyfDtf.js.map
