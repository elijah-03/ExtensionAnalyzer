const e={Resize:"Resize",Collapse:"Collapse"};export{e as T};
//# sourceMappingURL=TextRangeUpdateSemantics-D8MqPOrG-S_bbHJO0.js.map
