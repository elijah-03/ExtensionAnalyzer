import{a,A as s}from"./AsyncScheduler-BhBy18pz.js";var c=new a(s),e=c;export{c as a,e as b};
//# sourceMappingURL=async-BZW1XXsj.js.map
