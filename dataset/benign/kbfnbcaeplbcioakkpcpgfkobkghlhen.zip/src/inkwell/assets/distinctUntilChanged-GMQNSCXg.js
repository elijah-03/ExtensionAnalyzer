import{at as a,au as d,ao as v}from"./start-BFd-djfI.js";function c(i,n){return n===void 0&&(n=v),i=i!=null?i:o,a(function(s,t){var e,u=!0;s.subscribe(d(t,function(r){var f=n(r);(u||!i(e,f))&&(u=!1,e=f,t.next(r))}))})}function o(i,n){return i===n}export{c as d};
//# sourceMappingURL=distinctUntilChanged-GMQNSCXg.js.map
