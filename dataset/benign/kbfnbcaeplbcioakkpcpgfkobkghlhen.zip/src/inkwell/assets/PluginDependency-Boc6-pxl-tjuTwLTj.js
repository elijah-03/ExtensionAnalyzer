function e(n){return n}export{e as a};
//# sourceMappingURL=PluginDependency-Boc6-pxl-tjuTwLTj.js.map
