var e={now:function(){return(e.delegate||Date).now()},delegate:void 0};export{e as d};
//# sourceMappingURL=dateTimestampProvider-CV0dHcg-.js.map
