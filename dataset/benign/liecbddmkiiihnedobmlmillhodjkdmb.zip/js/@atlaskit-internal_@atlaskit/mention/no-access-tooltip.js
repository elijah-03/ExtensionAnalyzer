"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c2620b73-be83-5a7e-8564-d685c9da36fe")}catch(e){}}();
(self.webpackChunk_loomhq_chrome_extension=self.webpackChunk_loomhq_chrome_extension||[]).push([[17074],{34338:(e,n,t)=>{t.r(n),t.d(n,{NoAccessTooltip:()=>s});var o=t(48736),r=t(92860),c=t(12360),s=function(e){var n=e.name,t=e.children;return r.createElement(c.I9,{values:{name:n}},(function(e){return r.createElement(o.A,{content:e,position:"right"},t)}))}}}]);
//# sourceMappingURL=no-access-tooltip.js.map
//# debugId=c2620b73-be83-5a7e-8564-d685c9da36fe
