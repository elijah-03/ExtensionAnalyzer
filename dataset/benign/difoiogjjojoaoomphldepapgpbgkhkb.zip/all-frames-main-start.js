"use strict";(()=>{function e(){window.name.startsWith("sider-link-preview-iframe-")&&location.host.startsWith("www.zaobao.com")&&Reflect.defineProperty(window,"frameElement",{value:null})}e();})();
