chrome.tabs.create({ url: chrome.extension.getURL("html/index2.html") });
window.close();
