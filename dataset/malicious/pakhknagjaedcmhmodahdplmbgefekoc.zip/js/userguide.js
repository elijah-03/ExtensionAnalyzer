$('#title_h1').html ($('#title_h1').html()+chrome.i18n.getMessage("extension_name"));
//document.getElementById('extension_icon').src=chrome.extension.getURL('icon.png');