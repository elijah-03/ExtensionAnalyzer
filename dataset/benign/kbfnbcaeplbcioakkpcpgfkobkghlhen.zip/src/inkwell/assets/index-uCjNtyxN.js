import{d as o}from"./PluginModule-CRib3PLZ-B43Hjk20.js";import{c as t}from"./start-BFd-djfI.js";const r=t(Symbol("CAPISuggestionStore")),i=o({background:()=>import("./index-Dk3R999A.js")});export{r as CAPISuggestionStoreToken,i as activate};
//# sourceMappingURL=index-uCjNtyxN.js.map
