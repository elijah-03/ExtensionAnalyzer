
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="02739537-ea8c-56bd-ab74-557977966db8")}catch(e){}}();
import{a as t,b as e}from"/chunks/chunk-EXMDW5FT.js";import{c as l}from"/chunks/chunk-54UHBIHR.js";var g=l(t()),o=l(e()),d=C=>(0,o.jsx)("svg",{width:16,height:16,viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",...C,children:(0,o.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 15C4.13401 15 1 11.866 1 8V4C1 2.34315 2.34315 1 4 1H8C11.866 1 15 4.13401 15 8C15 11.866 11.866 15 8 15ZM5.5 7C6.32843 7 7 6.32843 7 5.5C7 4.67157 6.32843 4 5.5 4C4.67157 4 4 4.67157 4 5.5C4 6.32843 4.67157 7 5.5 7Z",fill:"#43A670"})}),i=d;export{i as default};

//# debugId=02739537-ea8c-56bd-ab74-557977966db8
