import{c as r}from"./RemoteEntity-CN-1WB86-yD3y8ldD.js";const i=r("TextDecorationsViewControllerEntity");function s(e,t){if(e.size!==t.size)return!1;for(const o of e)if(!t.has(o))return!1;return!0}export{i as T,s as e};
//# sourceMappingURL=index-DIq9RWYQ.js.map
