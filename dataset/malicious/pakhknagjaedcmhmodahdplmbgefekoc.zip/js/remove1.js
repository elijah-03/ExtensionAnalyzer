//修改wordpress的js
$(".choose").remove();
$(".description").remove();
$(".custom-header-media").css("height","140px")
//$('[rel="home"]').text("Wallpapers libraries by QQLife New Tab")
//$(".site-description").text("")
$("img").css("height","140px");

 
