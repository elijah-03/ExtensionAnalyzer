import{U as o}from"./index-uVYElzgq.js";function s(e){switch(e){case"extension-chrome":case"extension-firefox":case"extension-safari":case"preview-web":return"showAllDocuments";case"windows":case"preview-windows":return"showActiveDocumentOnly";default:throw new o(e)}}export{s as g};
//# sourceMappingURL=getDecorationStrategy-D8c5vEyH.js.map
