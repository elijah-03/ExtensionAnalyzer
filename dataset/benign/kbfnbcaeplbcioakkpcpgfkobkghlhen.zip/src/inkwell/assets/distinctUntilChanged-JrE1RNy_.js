import{aK as a,aL as d,aE as v}from"./index-uVYElzgq.js";function b(i,n){return n===void 0&&(n=v),i=i!=null?i:o,a(function(s,t){var e,r=!0;s.subscribe(d(t,function(u){var f=n(u);(r||!i(e,f))&&(r=!1,e=f,t.next(u))}))})}function o(i,n){return i===n}export{b as d};
//# sourceMappingURL=distinctUntilChanged-JrE1RNy_.js.map
