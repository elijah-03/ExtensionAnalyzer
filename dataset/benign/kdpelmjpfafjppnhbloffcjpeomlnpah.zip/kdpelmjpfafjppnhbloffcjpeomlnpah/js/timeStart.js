// 页面最开始记下一个时间戳，用于统计页面启动(特指 vue.js 构建程序)消耗了多少时间
window.__timeStart__ = new Date()
