import{a3 as n,aW as a}from"./index-uVYElzgq.js";function s(r){return new n(function(e){a(r()).subscribe(e)})}export{s as d};
//# sourceMappingURL=defer-BLWpl2MB.js.map
