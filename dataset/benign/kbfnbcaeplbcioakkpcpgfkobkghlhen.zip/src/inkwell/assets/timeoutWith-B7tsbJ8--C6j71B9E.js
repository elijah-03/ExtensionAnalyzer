import{ag as r,r as e}from"./start-BFd-djfI.js";import{r as m}from"./race-BWu18h02.js";import{t as u}from"./timer--E-2U5R1.js";import{t as i}from"./tap-BNGPOE-c.js";async function s(t,a){return await r(m([t,u(a.timeoutMs).pipe(i(a.onTimeout),e(()=>a.defaultValue))]),{defaultValue:a.defaultValue})}export{s as t};
//# sourceMappingURL=timeoutWith-B7tsbJ8--C6j71B9E.js.map
