import{p as e}from"./mergeAll-D275NTmK.js";import{D as t}from"./start-BFd-djfI.js";function f(){for(var o=[],r=0;r<arguments.length;r++)o[r]=arguments[r];var a=e(o);return t(o,a)}export{f as o};
//# sourceMappingURL=of-Boi_-3cC.js.map
