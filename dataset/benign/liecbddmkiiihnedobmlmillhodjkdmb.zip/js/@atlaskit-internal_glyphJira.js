"use strict";(self.webpackChunk_loomhq_chrome_extension=self.webpackChunk_loomhq_chrome_extension||[]).push([[24115],{18162:(e,o,c)=>{c.r(o),c.d(o,{JiraIcon:()=>h.cJ});var h=c(83406)}}]);
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b635bc52-8cb9-56eb-b637-6f5a820744d6")}catch(e){}}();
//# debugId=b635bc52-8cb9-56eb-b637-6f5a820744d6
