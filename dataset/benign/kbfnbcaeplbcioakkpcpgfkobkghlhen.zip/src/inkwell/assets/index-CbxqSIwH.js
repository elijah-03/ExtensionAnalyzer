import{d as o}from"./PluginModule-CRib3PLZ-B43Hjk20.js";import"./start-BFd-djfI.js";const i=o({background:()=>import("./index-BhOAJbfU.js"),foreground:()=>import("./index-r71BE6C2.js")});export{i as activate};
//# sourceMappingURL=index-CbxqSIwH.js.map
