import{E as o}from"./mergeAll-CSDR5lBs.js";import{aK as f,aL as i}from"./index-uVYElzgq.js";function c(e){return e<=0?function(){return o}:f(function(a,t){var r=0;a.subscribe(i(t,function(n){++r<=e&&(t.next(n),e<=r&&t.complete())}))})}export{c as t};
//# sourceMappingURL=take-A312jYgg.js.map
