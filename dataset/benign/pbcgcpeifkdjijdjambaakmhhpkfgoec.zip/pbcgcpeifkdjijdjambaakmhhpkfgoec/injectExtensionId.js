/**
 * Внедряемый контентный скрипт, проставлящий переменную sbisPluginExtensionInfo, по которой страница может понять,
 * что расширение установлено
 */
window.sbisPluginExtensionInfo = true;