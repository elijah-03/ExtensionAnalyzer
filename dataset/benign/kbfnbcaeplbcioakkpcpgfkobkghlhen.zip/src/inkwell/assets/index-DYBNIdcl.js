import{c as o}from"./start-BFd-djfI.js";import{d as e}from"./PluginModule-CRib3PLZ-B43Hjk20.js";const t=o(Symbol("MainView")),a=o(Symbol("MainViewContainer")),r=e({foreground:()=>import("./index-DWJjIIWF.js")});export{a as MainViewContainerToken,t as MainViewToken,r as activate};
//# sourceMappingURL=index-DYBNIdcl.js.map
