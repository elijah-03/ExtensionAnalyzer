
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2dce6ea5-5e94-5275-a59c-40cd549998ef")}catch(e){}}();
import{c as t}from"/chunks/chunk-WCG7Q5A6.js";import"/chunks/chunk-7OGXR7VM.js";import"/chunks/chunk-U3DUDNXO.js";import"/chunks/chunk-PTEF4S3V.js";import"/chunks/chunk-54UHBIHR.js";var d=t()??"double-pane";document.body.setAttribute("data-width",d);

//# debugId=2dce6ea5-5e94-5275-a59c-40cd549998ef
