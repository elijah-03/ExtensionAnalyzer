export const DEFAULT_VIDEO_FORMAT = 'mp4';
