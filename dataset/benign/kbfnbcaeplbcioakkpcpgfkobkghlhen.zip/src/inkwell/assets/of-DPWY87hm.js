import{p as e}from"./mergeAll-CSDR5lBs.js";import{J as t}from"./index-uVYElzgq.js";function f(){for(var o=[],r=0;r<arguments.length;r++)o[r]=arguments[r];var a=e(o);return t(o,a)}export{f as o};
//# sourceMappingURL=of-DPWY87hm.js.map
