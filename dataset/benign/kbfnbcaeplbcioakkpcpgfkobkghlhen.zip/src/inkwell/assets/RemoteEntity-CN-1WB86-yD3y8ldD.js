function t(e){return e}export{t as c};
//# sourceMappingURL=RemoteEntity-CN-1WB86-yD3y8ldD.js.map
